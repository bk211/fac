for i in `seq 1 100`; do
    echo "TIC"
    sleep 1
    echo "TAC"
    sleep 15
done
