for i in `seq 1 100`; do
    echo "Ti-ec"
    sleep 1
    echo "Ta-oc"
    sleep 10
done
