for i in `seq 1 100`; do
    echo "tic"
    sleep 1
    echo "tac"
    sleep 10
done
